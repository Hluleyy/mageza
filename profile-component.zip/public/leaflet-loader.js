// This file loads Leaflet.js and CSS for OpenStreetMap usage
// It is loaded via CDN for simplicity
